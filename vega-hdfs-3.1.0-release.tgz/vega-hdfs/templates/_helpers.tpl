{{/* vim: set filetype=mustache: */}}
{{/*
Create a short app name.
*/}}
{{- define "vega.name" -}}
hdfs
{{- end -}}

{{/*
Create chart name and version as used by the subchart label.
*/}}
{{- define "vega.subchart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "vega.fullname" -}}
vega-journalnode
{{- end -}}

{{- define "vega.journalnode.name" -}}
{{- template "vega.name" . -}}-journalnode
{{- end -}}

{{- define "vega.journalnode.fullname" -}}
{{- $fullname := include "vega.fullname" . -}}
{{- if contains "journalnode" $fullname -}}
{{- printf "%s" $fullname -}}
{{- else -}}
{{- printf "%s-journalnode" $fullname | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}


{{/*
Create the domain name part of services.
The HDFS config file should specify FQDN of services. Otherwise, Kerberos
login may fail.
*/}}
{{- define "svc-domain" -}}
{{- printf "%s.svc.cluster.local" "anyshare" -}}
{{- end -}}


{{/*
Create the journalnode quorum server list.  The below uses two loops to make
sure the last item does not have the delimiter. It uses index 0 for the last
item since that is the only special index that helm template gives us.
*/}}
{{- define "journalnode-quorum" -}}
{{- $service := include "vega.journalnode.fullname" . -}}
{{- $domain := include "svc-domain" . -}}
{{- $replicas := .Values.global.journalnodeQuorumSize | int -}}
{{- range $i, $e := until $replicas -}}
  {{- if ne $i 0 -}}
    {{- printf "%s-%d.%s.%s:8485;" $service $i $service $domain -}}
  {{- end -}}
{{- end -}}
{{- range $i, $e := until $replicas -}}
  {{- if eq $i 0 -}}
    {{- printf "%s-%d.%s.%s:8485" $service $i $service $domain -}}
  {{- end -}}
{{- end -}}
{{- end -}}
